package com.example.prototypeb.ui.translator;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class TranslatorViewModel extends ViewModel {


}