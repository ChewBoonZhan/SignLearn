package com.example.prototypeb.ui.lesson;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class LessonViewModel extends ViewModel {


}